
    for(let i=1; i<=4; i++)
    {
        for(let j=i; j<=5-1; j++)
        {
            lbl1.innerHTML +=j +"&nbsp&nbsp&nbsp&nbsp";
        }
        lbl1.innerHTML +="<br><br>";
    }