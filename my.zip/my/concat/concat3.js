function btn1Click()
{
    lbl1.innerHTML = txt1.value + " " + txt2.value + " " + txt3.value;
}