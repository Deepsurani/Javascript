function btn1Click(){
    lbl1.innerHTML = parseInt(txt1.value) + parseInt(txt2.value);
}
function btn2Click(){
    lbl1.innerHTML = parseInt(txt1.value) - parseInt(txt2.value);
}
function btn3Click(){
    lbl1.innerHTML = parseInt(txt1.value) * parseInt(txt2.value);
}
function btn4Click(){
    lbl1.innerHTML = parseInt(txt1.value) / parseInt(txt2.value);
}