function btn1Click(){
    lbl1.innerHTML = parseInt(txt1.value) + parseInt(txt2.value) + parseInt(txt3.value) + parseInt(txt4.value) + parseInt(txt5.value);
    per.innerHTML = parseInt(lbl1.value) / 5;
}